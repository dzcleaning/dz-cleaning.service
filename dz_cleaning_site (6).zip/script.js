function switchLang(lang) {
  const sections = document.querySelectorAll('[data-lang]');
  sections.forEach(s => s.classList.remove('visible'));
  document.querySelectorAll(`[data-lang="${lang}"]`).forEach(s => s.classList.add('visible'));
}
window.onload = () => switchLang('ar');
